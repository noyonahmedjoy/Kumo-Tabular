# Supplementary material: code and results

Anonymized code and raw results for the submission "An Empirical Evaluation of a Pretrained Tabular Foundation Model
on Small Numerical Tables". No author-identifying information is included.

## Contents

| Path | Content |
|---|---|
| `src/` | Data loading (scikit-learn and OpenML), Kumo Tabular wrapper, baselines, metrics, benchmark runners, plots |
| `scripts/run_all.py` | Original two-dataset study (breast cancer, diabetes) |
| `scripts/select_openml_suite.py` | Applies the dataset inclusion criteria to OpenML-CC18 and OpenML-CTR23 |
| `scripts/run_openml_benchmark.py` | Runs the OpenML benchmark (21 datasets) on the official OpenML 10-fold splits |
| `scripts/validate_openml_results.py` | Checks that every result file is complete and every metric valid |
| `scripts/analyze_openml_benchmark.py` | Pre-specified cross-dataset analysis (Friedman, Holm-corrected Wilcoxon, sensitivity analyses) |
| `paper/tmlr_submission/audit/ANALYSIS_PLAN.md` | Analysis plan written before the results were inspected, with recorded deviations |
| `paper/tmlr_submission/verify_statistics.py` | Independent recomputation of all reported statistics from the raw per-fold results |
| `tests/` | Unit tests, including data-leakage and prediction-shape checks |
| `configs/` | Experiment configuration and the selected OpenML suite |
| `results/` | Raw per-fold and per-split results, run logs, environment records, analysis outputs and figures |
| `notebooks/` | Self-contained notebooks for the original two-dataset study |

## Reproduce

Python 3.12, PyTorch with CUDA support for your GPU (CPU also works, more slowly), then:

```bash
pip install -r requirements.txt xgboost lightgbm catboost
python -m pytest
python scripts/run_all.py
python scripts/run_openml_benchmark.py
python scripts/validate_openml_results.py
python scripts/analyze_openml_benchmark.py
python paper/tmlr_submission/verify_statistics.py
```

The Kumo Tabular `small` checkpoints are downloaded from Hugging Face (`nvidia/Kumo-Tabular`) on first use; the OpenML
datasets and splits are downloaded from openml.org. Exact package versions of the reported run are in
`results/openml_benchmark/environment.json`. The suite selected by `scripts/select_openml_suite.py` contains 22
datasets; `forest_fires` (OpenML 44962) is excluded at load time because it contains text columns that its OpenML
metadata does not report (`configs/openml_suite.json`, `excluded_at_load`).
